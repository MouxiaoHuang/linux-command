# linux-command: Linux Command

`linux-command` 是一个用于执行特定命令行任务的工具。

## 安装

```bash
pip install linux-command
```

## 使用

```bash
cmd ls-dir
```
